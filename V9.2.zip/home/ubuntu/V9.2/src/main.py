from fastapi import FastAPI
from fastapi.responses import PlainTextResponse
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from src.services.api.routes import router

app = FastAPI(title="ECO·IA COPILOT V9.2", version="9.2.0")
app.include_router(router)

@app.get("/health")
async def health():
    return {"status": "ok", "service": "v9.2"}

@app.get("/ready")
async def ready():
    return {"status": "ready", "mission": "9.2.0"}

@app.get("/metrics")
def metrics():
    return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)
