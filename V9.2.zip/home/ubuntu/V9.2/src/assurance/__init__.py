"""V9.2 Assurance Layer."""
