from datetime import UTC, datetime
from .registry import AssuranceRegistry

class AssuranceEngine:
    """Technical assurance assessment; never represents external certification."""
    def __init__(self, registry: AssuranceRegistry | None = None):
        self.registry = registry or AssuranceRegistry()

    def assess(self) -> dict:
        validation = self.registry.validate()
        controls = self.registry.load()
        summary = {}
        for c in controls:
            summary.setdefault(c.framework, {"total": 0, "verified": 0, "pending": 0})
            summary[c.framework]["total"] += 1
            if c.verification_status == "VERIFIED":
                summary[c.framework]["verified"] += 1
            if c.external_review_required or c.verification_status in {"PENDING", "UNVERIFIED"}:
                summary[c.framework]["pending"] += 1
        return {
            "timestamp": datetime.now(UTC).isoformat(),
            "valid": validation["valid"],
            "controls": validation["controls"],
            "errors": validation["errors"],
            "frameworks": summary,
        }
