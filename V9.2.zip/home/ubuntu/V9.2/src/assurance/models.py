from dataclasses import dataclass, asdict
from typing import Any

@dataclass
class AssuranceControl:
    control_id: str
    framework: str
    title: str
    objective: str
    implementation_status: str
    evidence_status: str
    verification_status: str
    external_review_required: bool
    evidence_refs: list[str]
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
