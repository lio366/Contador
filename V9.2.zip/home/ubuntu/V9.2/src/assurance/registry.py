import json
from pathlib import Path
from .models import AssuranceControl

class AssuranceRegistry:
    VALID_STATUSES = {
        "IMPLEMENTED", "EXECUTED", "VERIFIED", "UNVERIFIED",
        "PENDING", "BLOCKED", "EXTERNAL_REVIEW_REQUIRED"
    }

    def __init__(self, path: str = "assurance/control_registry.json"):
        self.path = Path(path)

    def load(self) -> list[AssuranceControl]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return [AssuranceControl(**x) for x in data.get("controls", [])]

    def validate(self) -> dict:
        controls = self.load()
        errors = []
        for c in controls:
            for field, value in (
                ("implementation_status", c.implementation_status),
                ("evidence_status", c.evidence_status),
                ("verification_status", c.verification_status),
            ):
                if value not in self.VALID_STATUSES:
                    errors.append(f"{c.control_id}:{field}:{value}")
        return {"valid": not errors, "controls": len(controls), "errors": errors}
