from pathlib import Path
import json, subprocess
from src.tools.server_tools import project_inventory

def git_status(root: Path):
    if not (root/".git").exists(): return {"available":False}
    p=subprocess.run(["git","-C",str(root),"status","--short","--branch"],capture_output=True,text=True,check=False,timeout=30)
    return {"available":True,"status":p.stdout.strip(),"returncode":p.returncode}

def discover(name: str, root: Path):
    return {"project":name,"root":str(root),"inventory":project_inventory(root),"git":git_status(root),"compose_candidates":[str(p) for p in root.glob("*compose*.y*ml")],"tests_dir":(root/"tests").exists()}
