from src.agents.base_agent import BaseAgent

class SecurityAgent(BaseAgent):
    name="security"
    role="scope secrets tenant and zero-trust policy"
    capabilities=('scope', 'secrets', 'rbac', 'tenant')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
