from src.agents.base_agent import BaseAgent

class MasterAgent(BaseAgent):
    name="master"
    role="mission coordination"
    capabilities=('plan', 'dispatch', 'prioritize')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
