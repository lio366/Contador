from src.agents.base_agent import BaseAgent

class ResourcesAgent(BaseAgent):
    name="resources"
    role="CPU RAM disk and queue optimization"
    capabilities=('cpu', 'ram', 'disk', 'capacity')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
