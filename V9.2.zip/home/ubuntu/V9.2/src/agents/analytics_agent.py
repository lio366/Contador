from src.agents.base_agent import BaseAgent

class AnalyticsAgent(BaseAgent):
    name="analytics"
    role="metrics anomalies and reporting"
    capabilities=('metrics', 'anomaly', 'report')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
