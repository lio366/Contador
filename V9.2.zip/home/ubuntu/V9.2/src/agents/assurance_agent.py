from src.agents.base_agent import BaseAgent
from src.assurance.engine import AssuranceEngine

class AssuranceAgent(BaseAgent):
    name = "assurance"
    role = "continuous assurance control assessment and evidence binding"
    capabilities = ("assurance", "compliance_mapping", "evidence_binding", "control_assessment")

    async def handle(self, payload):
        result = AssuranceEngine().assess()
        return {
            "agent": self.name,
            "status": "VERIFIED" if result["valid"] else "FAIL",
            "data": result,
        }
