from src.agents.base_agent import BaseAgent

class RepairAgent(BaseAgent):
    name="repair"
    role="evidence-backed repair with rollback"
    capabilities=('diagnose', 'repair', 'rollback')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
