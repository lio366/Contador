from src.agents.base_agent import BaseAgent

class VerificationAgent(BaseAgent):
    name="verification"
    role="testing independent verification and evidence judgement"
    capabilities=('test', 'verify', 'critic', 'evidence')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
