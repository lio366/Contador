from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

@dataclass(slots=True)
class AgentResult:
    agent: str
    status: str
    data: dict[str, Any]

class BaseAgent(ABC):
    name="base"
    role="base"
    capabilities: tuple[str,...]=()
    def __init__(self, bus=None, policy=None, logger=None):
        self.bus=bus; self.policy=policy; self.logger=logger
        self.enabled=True
    @abstractmethod
    async def handle(self, payload: dict[str, Any]) -> dict[str, Any]: raise NotImplementedError
    async def health(self): return {"agent":self.name,"enabled":self.enabled,"capabilities":list(self.capabilities)}
