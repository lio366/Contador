from src.agents.base_agent import BaseAgent

class BuilderAgent(BaseAgent):
    name="builder"
    role="evidence-backed controlled implementation"
    capabilities=('patch', 'build')

    async def handle(self, payload):
        return {"agent":self.name,"status":"PROPOSED","role":self.role,"payload":payload}
