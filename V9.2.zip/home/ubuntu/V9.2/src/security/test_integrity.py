from pathlib import Path
import hashlib, json

def sha256_file(path: Path)->str:
    h=hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()

def verify_manifest(manifest_path="mission/protected_tests.json"):
    data=json.loads(Path(manifest_path).read_text()); failures=[]
    for rel,expected in data.items():
        p=Path(rel)
        if not p.exists() or sha256_file(p)!=expected: failures.append(rel)
    return {"valid":not failures,"failures":failures}
