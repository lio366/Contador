from pathlib import Path
class ScopeGuard:
    def __init__(self, allowed_roots): self.allowed=[Path(x).resolve() for x in allowed_roots]
    def check(self,path:str)->bool:
        target=Path(path).resolve(); return any(root==target or root in target.parents for root in self.allowed)
