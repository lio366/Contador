from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, Field
from config.settings import settings
from src.orchestrator.runtime import MissionRuntime

router=APIRouter()
runtime=MissionRuntime()

class DecisionRequest(BaseModel):
    action: str=Field(min_length=1)
    target: str|None=None
    project: str|None=None

@router.get("/mission")
async def mission(): return runtime.snapshot()

@router.post("/mission/run")
async def run_mission(x_v92_key: str|None=Header(default=None)):
    if settings.v92_api_key and x_v92_key != settings.v92_api_key: raise HTTPException(status_code=401,detail="unauthorized")
    return await runtime.run_cycle()

@router.get("/agents")
async def agents(): return runtime.agent_health()

@router.post("/decision")
async def decision(req: DecisionRequest): return runtime.policy.evaluate(req.action,req.target).value

@router.get("/evidence")
async def evidence(): return runtime.recent_evidence()

@router.get("/verification")
async def verification(): return runtime.last_verification
