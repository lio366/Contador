from datetime import datetime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Text, DateTime

class Base(DeclarativeBase): pass
class MissionRow(Base):
    __tablename__="missions"; id: Mapped[str]=mapped_column(String(64),primary_key=True); status: Mapped[str]=mapped_column(String(32)); created_at: Mapped[datetime]=mapped_column(DateTime); payload: Mapped[str]=mapped_column(Text)
class EvidenceRow(Base):
    __tablename__="evidence"; evidence_id: Mapped[str]=mapped_column(String(128),primary_key=True); verification_status: Mapped[str]=mapped_column(String(32)); record_json: Mapped[str]=mapped_column(Text); created_at: Mapped[datetime]=mapped_column(DateTime)
