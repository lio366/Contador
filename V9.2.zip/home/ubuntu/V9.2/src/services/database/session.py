from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from config.settings import settings
from src.services.database.models import Base

engine=create_async_engine(settings.postgres_dsn,pool_pre_ping=True)
Session=async_sessionmaker(engine,expire_on_commit=False)

async def init_db():
    async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
