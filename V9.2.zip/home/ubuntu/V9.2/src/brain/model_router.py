from src.brain.ollama import ask as ask_local
from src.brain.gpt41 import GPT41Brain

class ModelRouter:
    def __init__(self): self.gpt=GPT41Brain()
    async def ask(self,prompt: str,complex_task: bool=False)->str:
        if complex_task:
            try: return await self.gpt.ask(prompt)
            except Exception: pass
        return await ask_local(prompt)
