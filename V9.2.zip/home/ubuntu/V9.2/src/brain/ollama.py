import httpx
from config.settings import settings

async def ask(prompt: str) -> str:
    async with httpx.AsyncClient(timeout=120) as client:
        response=await client.post(f"{settings.ollama_url.rstrip('/')}/api/generate",json={"model":settings.ollama_model,"prompt":prompt,"stream":False})
        response.raise_for_status(); return response.json().get("response","")
