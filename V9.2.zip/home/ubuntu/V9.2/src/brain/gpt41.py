from openai import AsyncOpenAI
from config.settings import settings

class GPT41Brain:
    def __init__(self): self.client=AsyncOpenAI(api_key=settings.openai_api_key) if settings.openai_api_key else None
    async def ask(self, prompt: str) -> str:
        if not settings.openai_enabled or not self.client: raise RuntimeError("GPT-4.1 disabled or key unavailable")
        response=await self.client.responses.create(model=settings.openai_model,input=prompt)
        return response.output_text
