import asyncio
from src.core.redis_bus import RedisBus
from src.core.message import Message
from config.settings import settings

async def main():
    bus=RedisBus(settings.redis_url)
    await bus.append_stream("v92:executor",Message("executor","*",{"status":"READY"},event_type="executor.ready"))
    while True: await asyncio.sleep(3600)

if __name__=="__main__": asyncio.run(main())
