from pathlib import Path
import json

DOCS=["ARCHITECTURE.md","SECURITY.md","COMPLIANCE.md","LAS_MERCEDES_TENANT.md","INTEGRATION_MAP.md","AUTHORIZATION_MATRIX.md","TEST_MATRIX.md","EVIDENCE_REPORT.md","ZERO_TRUST_REPORT.md","RECOVERY_REPORT.md","FINAL_VERDICT.md"]

def generate_reports(snapshot: dict, out_root: str="evidence/reports"):
    root=Path(out_root); root.mkdir(parents=True,exist_ok=True)
    common=("# ECO·IA COPILOT V9.2\n\nGenerated from executed V9.2 state.\n\n"
            "Synthetic data remain SYNTHETIC. No real Las Mercedes integration is asserted.\n\n")
    for name in DOCS:
        text=common
        if name=="FINAL_VERDICT.md": text += f"## Final Verdict\n\n`{snapshot.get('verdict','NOT VERIFIED')}`\n\n## REAL EXECUTION\n{json.dumps(snapshot.get('real_execution',{}),indent=2)}\n\n## SYNTHETIC DATA\nSynthetic healthcare environment only.\n\n## PUBLIC INFORMATION\nOnly information explicitly sourced as public belongs here.\n\n## PENDING REAL INTEGRATION\nCredentials, authorization, real sandbox and external integration remain pending.\n"
        elif name=="TEST_MATRIX.md": text += "## Test Matrix\n\nHealthcare pytest; Healthcare unittest; Zero-Trust Compose verifier; protected-test integrity; evidence chain verification.\n"
        elif name=="EVIDENCE_REPORT.md": text += f"## Evidence\n\n{json.dumps(snapshot.get('evidence',[]),indent=2)}\n"
        else: text += "## Status\n\nThis document is generated from the current executable evidence set.\n"
        (root/name).write_text(text,encoding="utf-8")
    return [str(root/x) for x in DOCS]
