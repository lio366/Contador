from pathlib import Path
from datetime import UTC, datetime
import shutil

def make_checkpoint(root: str, checkpoint_root: str="evidence/checkpoints") -> Path:
    source=Path(root).resolve(); dest=Path(checkpoint_root)/f"{source.name}-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, dest, ignore=shutil.ignore_patterns(".git", "__pycache__", ".pytest_cache"))
    return dest

def rollback(checkpoint: str, target: str) -> None:
    src=Path(checkpoint); dst=Path(target)
    if not src.exists(): raise FileNotFoundError(checkpoint)
    if dst.exists(): shutil.rmtree(dst)
    shutil.copytree(src, dst)
