import json
from redis.asyncio import Redis
from src.core.message import Message

class RedisBus:
    def __init__(self, url: str): self.redis = Redis.from_url(url, decode_responses=True)

    async def publish(self, channel: str, message: Message) -> int:
        return await self.redis.publish(channel, message.to_json())

    async def append_stream(self, stream: str, message: Message) -> str:
        return await self.redis.xadd(stream, {"message": message.to_json()}, maxlen=10000, approximate=True)

    async def health(self) -> bool:
        return bool(await self.redis.ping())
