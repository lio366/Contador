from dataclasses import dataclass, field, asdict
from datetime import UTC, datetime
from typing import Any
import json, uuid

@dataclass(slots=True)
class Message:
    sender: str
    target: str
    content: dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    message_id: str | None = None
    mission_id: str | None = None
    task_id: str | None = None
    correlation_id: str | None = None
    event_type: str = "agent.message"
    priority: int = 50

    def __post_init__(self):
        self.message_id = self.message_id or str(uuid.uuid4())
        self.correlation_id = self.correlation_id or str(uuid.uuid4())

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self); data["timestamp"] = self.timestamp.isoformat(); return data

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, default=str)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Message":
        if isinstance(data.get("timestamp"), str): data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        return cls(**data)
