from enum import Enum
from pathlib import Path

class Decision(str, Enum):
    SAFE="SAFE"; CONTROLLED="CONTROLLED"; BLOCKED="BLOCKED"

class PolicyGate:
    SAFE = {"read","inspect","recon","test","collect_evidence","report"}
    CONTROLLED = {"write","build","repair","restart","backup","dependency_change"}
    BLOCKED = {"modify_tests","secret_export","scope_escape","real_external_action","disable_guardrails"}

    def evaluate(self, action: str, target: str | None = None) -> Decision:
        if action in self.BLOCKED: return Decision.BLOCKED
        if target and self._looks_excluded(target): return Decision.BLOCKED
        if action in self.CONTROLLED: return Decision.CONTROLLED
        return Decision.SAFE

    @staticmethod
    def _looks_excluded(target: str) -> bool:
        p = str(Path(target))
        return p.startswith("/home/ubuntu/ECO-IA") or p.startswith("/opt/taes")

    def can_write(self, target: str) -> bool:
        return self.evaluate("write", target) == Decision.CONTROLLED
