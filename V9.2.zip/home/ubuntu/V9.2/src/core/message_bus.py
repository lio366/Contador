"""TOMY-derived in-process async message bus."""
import asyncio
from collections.abc import Callable, Coroutine
from typing import Any
from src.core.message import Message

Handler = Callable[[Message], Coroutine[Any, Any, None]]

class MessageBus:
    def __init__(self, max_history: int = 1000):
        self._subscribers: dict[str, list[Handler]] = {}
        self._history: list[Message] = []
        self._max_history = max_history

    async def subscribe(self, agent_name: str, handler: Handler) -> None:
        self._subscribers.setdefault(agent_name, []).append(handler)

    async def unsubscribe(self, agent_name: str, handler: Handler) -> None:
        handlers = self._subscribers.get(agent_name, [])
        if handler in handlers: handlers.remove(handler)

    async def publish(self, message: Message) -> None:
        self._store(message)
        handlers: list[Handler] = []
        if message.target == "*":
            for group in self._subscribers.values():
                for handler in group:
                    if handler not in handlers: handlers.append(handler)
        else:
            handlers.extend(self._subscribers.get(message.target, []))
            for handler in self._subscribers.get("*", []):
                if handler not in handlers: handlers.append(handler)
        if handlers:
            await asyncio.gather(*(handler(message) for handler in handlers), return_exceptions=True)

    def _store(self, message: Message) -> None:
        self._history.append(message)
        if len(self._history) > self._max_history: self._history = self._history[-self._max_history:]

    def get_history(self, limit: int = 50) -> list[Message]: return self._history[-limit:]
    def get_stats(self) -> dict[str, Any]: return {"total_messages": len(self._history), "subscribers": {k: len(v) for k,v in self._subscribers.items()}}
