import json
from pathlib import Path

class MissionController:
    def __init__(self, contract_path: str="mission/mission_contract.json", scope_path: str="mission/scope.json"):
        self.contract = json.loads(Path(contract_path).read_text())
        self.scope = json.loads(Path(scope_path).read_text())

    def allowed(self, project: str) -> bool:
        return project in self.scope["allowed_projects"]

    def excluded(self, path: str) -> bool:
        p = str(Path(path))
        return any(p.startswith(x) for x in self.scope["excluded_paths"])

    def project_root(self, project: str) -> Path:
        if not self.allowed(project): raise PermissionError("Project outside mission scope")
        return Path(self.scope["allowed_projects"][project])
