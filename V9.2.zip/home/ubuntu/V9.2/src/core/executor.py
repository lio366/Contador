from pathlib import Path
import subprocess

class ExecutionError(RuntimeError): pass

class SafeExecutor:
    """Deterministic executor. It permits only known procedures and allowed roots."""
    def __init__(self, allowed_roots: list[str], timeout: int=900):
        self.allowed_roots=[Path(x).resolve() for x in allowed_roots]; self.timeout=timeout

    def path_allowed(self, path: str) -> bool:
        target=Path(path).resolve(); return any(root==target or root in target.parents for root in self.allowed_roots)

    def run(self, args: list[str], cwd: str) -> subprocess.CompletedProcess[str]:
        if not self.path_allowed(cwd): raise PermissionError(f"Execution path outside mission scope: {cwd}")
        return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=False, timeout=self.timeout)

    def run_healthcare(self, root: Path) -> subprocess.CompletedProcess[str]:
        candidates=[]
        venv=root/".venv/bin/python"
        if venv.exists(): candidates=[str(venv), "-m", "pytest", "-q"]
        else: candidates=["python3", "-m", "pytest", "-q"]
        return self.run(candidates, "/workspace/healthcare")

    def run_unittest(self, root: Path) -> subprocess.CompletedProcess[str]:
        venv=root/".venv/bin/python"
        py=str(venv) if venv.exists() else "python3"
        return self.run([py, "-m", "unittest", "discover", "-s", "tests", "-v"], str(root))

    def run_zero_trust_compose(self, root: Path) -> subprocess.CompletedProcess[str]:
        candidates=[root/"docker-compose.yml", root/"docker-compose.yaml", root/"compose.yml", root/"compose.yaml"]
        compose=next((p for p in candidates if p.exists()), None)
        if not compose: raise FileNotFoundError("No compose file found for Zero-Trust project")
        return self.run(["docker","run","--rm","--network","ecoia_zero_trust_autonomous_default","-e","AUDIT_ENGINE_URL=http://audit-engine:3000","-v",f"{root}:/src:ro","-w","/tmp/zt","node:22-alpine","sh","-lc","cp -a /src/. /tmp/zt/ && npm install --omit=dev >/dev/null 2>&1 && node full-zero-trust-test.js"], "/workspace/zero_trust")
