from src.evidence.ledger import EvidenceLedger

def verify_ledger(path="evidence/ledger.jsonl"):
    return EvidenceLedger(path).verify_chain()
