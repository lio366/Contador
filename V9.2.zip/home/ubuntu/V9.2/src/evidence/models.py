from dataclasses import dataclass, asdict
from typing import Any
import uuid

@dataclass
class EvidenceRecord:
    source: str
    resource: str
    actor: str
    tenant: str
    workflow: str
    input_hash: str | None
    output_hash: str | None
    policy: str
    decision: str
    provenance: str
    verification_status: str
    classification: str
    evidence_id: str = ""
    signature: str | None = None
    def to_dict(self) -> dict[str,Any]:
        data=asdict(self); data["evidence_id"]=data["evidence_id"] or f"EV-{uuid.uuid4()}"; return data
