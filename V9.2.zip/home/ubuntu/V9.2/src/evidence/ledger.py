from pathlib import Path
from datetime import UTC, datetime
import hashlib, json

class EvidenceLedger:
    def __init__(self, path: str="evidence/ledger.jsonl"):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def canonical(record: dict) -> bytes:
        return json.dumps(record, sort_keys=True, separators=(",",":"), ensure_ascii=False, default=str).encode()

    def append(self, record: dict) -> dict:
        prior="GENESIS"
        if self.path.exists():
            with self.path.open(encoding="utf-8") as f:
                for line in f:
                    try: prior=json.loads(line)["record_hash"]
                    except Exception: continue
        clean={k:v for k,v in record.items() if k not in {"record_hash","prev_hash","timestamp"}}
        clean["timestamp"]=datetime.now(UTC).isoformat(); clean["prev_hash"]=prior
        digest=hashlib.sha256(self.canonical(clean)).hexdigest()
        item={**clean,"record_hash":digest}
        with self.path.open("a",encoding="utf-8") as f: f.write(json.dumps(item,sort_keys=True,default=str)+"\n")
        return item

    def verify_chain(self) -> dict:
        if not self.path.exists(): return {"valid":True,"records":0}
        prior="GENESIS"; count=0
        with self.path.open(encoding="utf-8") as f:
            for line in f:
                item=json.loads(line); expected=item.pop("record_hash");
                if item.get("prev_hash") != prior: return {"valid":False,"records":count,"error":"prev_hash_mismatch"}
                actual=hashlib.sha256(self.canonical(item)).hexdigest()
                if actual != expected: return {"valid":False,"records":count,"error":"record_hash_mismatch"}
                prior=expected; count+=1
        return {"valid":True,"records":count}
