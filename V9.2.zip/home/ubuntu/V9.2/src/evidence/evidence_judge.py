class EvidenceJudge:
    def decide(self, *, executed: bool, ledger_valid: bool, independent_verified: bool, skipped: bool=False) -> str:
        if not executed: return "NOT VERIFIED"
        if skipped: return "NOT VERIFIED"
        if executed and ledger_valid and independent_verified: return "VERIFIED"
        if executed and ledger_valid: return "PARTIAL"
        return "FAIL"
