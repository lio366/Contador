from pathlib import Path

def project_inventory(root: Path):
    return {"exists":root.exists(),"files":sum(1 for _ in root.rglob("*") if _.is_file()) if root.exists() else 0,"git":(root/".git").exists()}
