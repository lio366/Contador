import shutil, psutil

def snapshot():
    total,used,free=shutil.disk_usage("/")
    return {"cpu_percent":psutil.cpu_percent(interval=0.1),"ram_percent":psutil.virtual_memory().percent,"disk_used_percent":round(used/total*100,2),"disk_free_bytes":free}
