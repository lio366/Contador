def notify(message: str): return {"status":"QUEUED","message":message}
