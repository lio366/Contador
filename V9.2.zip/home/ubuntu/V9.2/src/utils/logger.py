import json
import logging
import re
from typing import Any

SECRET_KEYS = {"authorization", "api_key", "apikey", "token", "secret", "password", "private_key"}

def redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if k.lower() in SECRET_KEYS else redact(v)) for k,v in value.items()}
    if isinstance(value, list): return [redact(v) for v in value]
    if isinstance(value, str): return re.sub(r"(?i)(bearer\\s+|sk-[A-Za-z0-9_-]+)", "[REDACTED]", value)
    return value

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {"ts": self.formatTime(record, self.datefmt), "level": record.levelname, "logger": record.name, "message": record.getMessage()}
        return json.dumps(redact(payload), ensure_ascii=False, default=str)

def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    return logger
