from pathlib import Path
from datetime import datetime, UTC
import asyncio, json, hashlib
from src.core.mission_controller import MissionController
from src.core.policy_gate import PolicyGate
from src.core.executor import SafeExecutor
from src.core.message_bus import MessageBus
from src.core.redis_bus import RedisBus
from src.core.checkpoint import make_checkpoint, rollback
from src.evidence.ledger import EvidenceLedger
from src.evidence.evidence_judge import EvidenceJudge
from src.security.test_integrity import verify_manifest
from src.mission.recon import discover
from src.reporting import generate_reports
from src.tools.monitoring_tools import snapshot as resource_snapshot
from src.brain.model_router import ModelRouter
from src.agents.master_agent import MasterAgent
from src.agents.monetization_agent import MonetizationAgent
from src.agents.devops_agent import DevOpsAgent
from src.agents.resources_agent import ResourcesAgent
from src.agents.security_agent import SecurityAgent
from src.agents.analytics_agent import AnalyticsAgent
from src.agents.builder_agent import BuilderAgent
from src.agents.repair_agent import RepairAgent
from src.agents.verification_agent import VerificationAgent
from config.settings import settings

class MissionRuntime:
    def __init__(self):
        self.mission=MissionController(); self.policy=PolicyGate(); self.bus=MessageBus(); self.redis=RedisBus(settings.redis_url)
        roots=[self.mission.project_root("healthcare"),self.mission.project_root("zero_trust")]
        self.executor=SafeExecutor([str(x) for x in roots],settings.execution_timeout_seconds)
        self.ledger=EvidenceLedger(); self.judge=EvidenceJudge(); self.router=ModelRouter()
        self.agents=[MasterAgent(),MonetizationAgent(),DevOpsAgent(),ResourcesAgent(),SecurityAgent(),AnalyticsAgent(),BuilderAgent(),RepairAgent(),VerificationAgent()]
        self.last_verification={"status":"NOT VERIFIED"}; self._running=False

    def snapshot(self): return {"version":"9.2.0","autonomy":settings.autonomy_enabled,"projects":list(self.mission.scope["allowed_projects"]),"last_verification":self.last_verification}
    def agent_health(self): return [{"name":a.name,"role":a.role,"enabled":a.enabled} for a in self.agents]
    def recent_evidence(self):
        p=Path("evidence/ledger.jsonl");
        if not p.exists(): return []
        rows=[]
        for line in p.read_text(encoding="utf-8").splitlines()[-20:]:
            try: rows.append(json.loads(line))
            except Exception: pass
        return rows

    def _evidence(self, source, resource, workflow, decision, classification="REAL", **extra):
        rec={"source":source,"resource":resource,"actor":"v9.2","tenant":"TENANT-LMC-SYN","workflow":workflow,"input_hash":extra.get("input_hash"),"output_hash":extra.get("output_hash"),"policy":decision,"decision":decision,"provenance":"V9.2_EXECUTION","verification_status":extra.get("verification_status","UNVERIFIED"),"classification":classification}
        return self.ledger.append(rec)

    async def run_cycle(self):
        if self._running: return {"status":"BLOCKED","reason":"cycle_already_running"}
        self._running=True
        try:
            mission_id=f"M-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
            recon={k:discover(k,self.mission.project_root(k)) for k in self.mission.scope["allowed_projects"]}
            integrity=verify_manifest()
            if not integrity["valid"]: return self._final("BLOCKED",recon,[],{"test_integrity":integrity},mission_id)
            evidence=[]
            evidence.append(self._evidence("recon","allowed_projects","DISCOVERY","PASS",output_hash=hashlib.sha256(json.dumps(recon,sort_keys=True).encode()).hexdigest(),verification_status="EXECUTED"))

            # Healthcare real execution against synthetic data in the authorized repository.
            hc=self.mission.project_root("healthcare")
            try:
                p=self.executor.run_healthcare(hc)
                hc_status="PASS" if p.returncode==0 else "FAIL"
                skipped="skipped" in p.stdout.lower() or "skipped" in p.stderr.lower()
                evidence.append(self._evidence("pytest",str(hc),"TESTING",hc_status,verification_status="EXECUTED" if not skipped else "UNVERIFIED",output_hash=hashlib.sha256((p.stdout+p.stderr).encode()).hexdigest()))
            except Exception as exc:
                hc_status="FAIL"; evidence.append(self._evidence("pytest",str(hc),"TESTING","FAIL",verification_status="UNVERIFIED"));

            # Zero-Trust exact Compose-context reproduction.
            zt=self.mission.project_root("zero_trust")
            try:
                zp=self.executor.run_zero_trust_compose(zt)
                zt_status="PASS" if zp.returncode==0 else "FAIL"
                evidence.append(self._evidence("docker-compose","zero-trust-verifier","ZERO-TRUST VERIFICATION",zt_status,verification_status="EXECUTED",output_hash=hashlib.sha256((zp.stdout+zp.stderr).encode()).hexdigest()))
            except Exception:
                zt_status="FAIL"; evidence.append(self._evidence("docker-compose","zero-trust-verifier","ZERO-TRUST VERIFICATION","FAIL",verification_status="UNVERIFIED"))

            # Independent verification is ledger-chain validation plus deterministic reproduction status.
            chain=self.ledger.verify_chain(); independent=(hc_status=="PASS" and zt_status=="PASS" and chain["valid"])
            verdict=self.judge.decide(executed=True,ledger_valid=chain["valid"],independent_verified=independent,skipped=False)

            # Controlled repair hook. It never edits tests and requires evidence of failure.
            if settings.autonomy_enabled and verdict in {"FAIL","PARTIAL"} and settings.max_repair_iterations>0:
                proposal=await self._ask_critic(hc_status,zt_status,recon)
                if proposal.get("action") in {"repair","build"}:
                    repair_decision=self.policy.evaluate(proposal["action"])
                    if repair_decision.value=="CONTROLLED":
                        # Do not apply an LLM patch blindly. Record a controlled plan; the concrete patch implementation is intentionally gated.
                        evidence.append(self._evidence("repair","controlled_plan","IMPLEMENTATION", "CONTROLLED", verification_status="PROPOSED", output_hash=hashlib.sha256(json.dumps(proposal,sort_keys=True).encode()).hexdigest()))
                        verdict="PARTIAL"

            final={"mission_id":mission_id,"real_execution":{"healthcare":hc_status,"zero_trust":zt_status},"evidence":evidence[-20:],"resource_snapshot":resource_snapshot(),"ledger":chain,"verdict":verdict,"test_integrity":integrity}
            generate_reports(final)
            self.last_verification=final
            return final
        finally: self._running=False

    async def _ask_critic(self,hc_status,zt_status,recon):
        prompt=("You are the V9.2 critic. Analyze only supplied execution evidence. "
                f"Healthcare={hc_status}; ZeroTrust={zt_status}; recon={json.dumps(recon,sort_keys=True)}. "
                "Return JSON only: {\"action\":\"none|repair|build\",\"reason\":\"...\"}. Never propose test modification or scope expansion.")
        try:
            raw=await self.router.ask(prompt,complex_task=(hc_status=="FAIL" and zt_status=="FAIL"))
            start=raw.find("{"); end=raw.rfind("}"); return json.loads(raw[start:end+1])
        except Exception: return {"action":"none","reason":"critic_unavailable"}

    def _final(self,verdict,recon,evidence,extra,mission_id):
        final={"mission_id":mission_id,"real_execution":recon,"evidence":evidence,"verdict":verdict,**extra}; generate_reports(final); self.last_verification=final; return final

async def daemon():
    runtime=MissionRuntime()
    while True:
        try: await runtime.run_cycle()
        except Exception: pass
        await asyncio.sleep(settings.mission_interval_seconds)

if __name__=="__main__": asyncio.run(daemon())
