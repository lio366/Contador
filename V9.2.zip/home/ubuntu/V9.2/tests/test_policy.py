from src.core.policy_gate import PolicyGate, Decision

def test_policy_gate():
    gate=PolicyGate()
    assert gate.evaluate("read")==Decision.SAFE
    assert gate.evaluate("repair")==Decision.CONTROLLED
    assert gate.evaluate("modify_tests")==Decision.BLOCKED
    assert gate.evaluate("scope_escape")==Decision.BLOCKED
