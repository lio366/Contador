from src.core.policy_gate import PolicyGate

def test_excluded_scope_is_blocked():
    assert PolicyGate().evaluate("read","/opt/taes2/repo").value=="BLOCKED"
