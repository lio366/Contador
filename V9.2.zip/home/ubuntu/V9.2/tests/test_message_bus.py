import pytest
from src.core.message import Message
from src.core.message_bus import MessageBus

@pytest.mark.asyncio
async def test_tomy_bus_delivery_and_history():
    bus=MessageBus(); received=[]
    async def handler(message): received.append(message.message_id)
    await bus.subscribe("builder",handler)
    msg=Message("master","builder",{"action":"inspect"})
    await bus.publish(msg)
    assert received==[msg.message_id]
    assert bus.get_history(1)[0].message_id==msg.message_id
