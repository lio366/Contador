from pathlib import Path
from src.evidence.ledger import EvidenceLedger

def test_ledger_roundtrip(tmp_path: Path):
    ledger=EvidenceLedger(str(tmp_path/"ledger.jsonl"))
    ledger.append({"source":"test","resource":"r","actor":"a","tenant":"t","workflow":"w","input_hash":None,"output_hash":None,"policy":"PASS","decision":"PASS","provenance":"unit","verification_status":"EXECUTED","classification":"REAL"})
    assert ledger.verify_chain()["valid"]
