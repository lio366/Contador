import pytest
from src.agents.base_agent import BaseAgent
from src.agents.builder_agent import BuilderAgent
from src.agents.repair_agent import RepairAgent

@pytest.mark.asyncio
async def test_agents_share_base_contract():
    for agent in (BuilderAgent(),RepairAgent()):
        assert isinstance(agent,BaseAgent)
        assert (await agent.health())["enabled"] is True
