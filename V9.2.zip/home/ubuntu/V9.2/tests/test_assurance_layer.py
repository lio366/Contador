import json
from pathlib import Path
from src.assurance.registry import AssuranceRegistry

def test_assurance_registry_is_valid():
    result = AssuranceRegistry("assurance/control_registry.json").validate()
    assert result["valid"] is True
    assert result["controls"] > 0

def test_external_review_not_claimed_verified():
    data = json.loads(Path("assurance/control_registry.json").read_text())
    for c in data["controls"]:
        if c["external_review_required"]:
            assert c["verification_status"] != "VERIFIED" or c["evidence_status"] in {"VERIFIED", "EXECUTED"}

def test_frameworks_present():
    data = json.loads(Path("assurance/control_registry.json").read_text())
    frameworks = {c["framework"] for c in data["controls"]}
    assert {"HIPAA","BAA","HTI-1","SOC2","HITRUST-CSF","ONC"} <= frameworks
