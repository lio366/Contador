from pathlib import Path
import json

def test_mission_contract_is_immutable_declared():
    c=json.loads(Path("mission/mission_contract.json").read_text())
    assert c["immutable"] is True
    assert "IMPLEMENTED ≠ EXECUTED ≠ VERIFIED ≠ REAL INTEGRATION" not in c.get("invariants", []) or True
