from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    log_level: str = "INFO"
    api_host: str = "0.0.0.0"
    api_port: int = 8080
    postgres_dsn: str
    redis_url: str
    healthcare_host_path: str
    zero_trust_host_path: str
    healthcare_container_path: str = "/workspace/healthcare"
    zero_trust_container_path: str = "/workspace/zero_trust"
    ollama_url: str = "http://host.docker.internal:11434"
    ollama_model: str = "qwen2.5-coder:3b"
    openai_enabled: bool = False
    openai_model: str = "gpt-4.1"
    openai_api_key: str | None = None
    stripe_enabled: bool = False
    stripe_secret_key: str | None = None
    mission_interval_seconds: int = 1800
    autonomy_enabled: bool = True
    max_repair_iterations: int = 2
    execution_timeout_seconds: int = 900
    v92_api_key: str | None = None
    evidence_signing_key_path: str | None = None
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
