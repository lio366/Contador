#!/usr/bin/env bash
set -euo pipefail
docker compose up -d --build
printf '%s\n' "V9.2 STARTED"
