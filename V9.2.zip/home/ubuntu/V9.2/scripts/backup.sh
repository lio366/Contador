#!/usr/bin/env bash
set -euo pipefail
mkdir -p backups
docker compose exec -T postgres pg_dump -U v92 v92 > "backups/v92-$(date +%Y%m%d_%H%M%S).sql"
