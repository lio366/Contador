#!/usr/bin/env bash
set -euo pipefail
INSTALL_ROOT=/home/ubuntu/ECOIA_COPILOT_V9_2
sudo mkdir -p "$INSTALL_ROOT"
sudo cp -a ./. "$INSTALL_ROOT/"
sudo chown -R ubuntu:ubuntu "$INSTALL_ROOT"
sudo tee /etc/systemd/system/ecoia-v92.service >/dev/null <<EOF
[Unit]
Description=ECO-IA V9.2 Autonomous Governed Agent Platform
After=docker.service network-online.target
Wants=network-online.target
Requires=docker.service

[Service]
Type=simple
User=ubuntu
Group=ubuntu
WorkingDirectory=$INSTALL_ROOT
Environment=HOME=/home/ubuntu
Environment=PYTHONUNBUFFERED=1
ExecStart=/usr/bin/docker compose up --remove-orphans --exit-code-from orchestrator
Restart=always
RestartSec=15
UMask=0027
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now ecoia-v92.service
printf '%s\n' "ECOIA V9.2 AUTONOMOUS ACTIVE"
