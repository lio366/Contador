#!/usr/bin/env bash
set -euo pipefail
python3 -m pytest -q
python3 -m ruff check .
docker compose config >/dev/null
printf '%s\n' "V9.2 STATIC VERIFICATION PASS"
