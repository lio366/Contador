#!/usr/bin/env bash
set -euo pipefail
cp -n .env.example .env || true
python3 -m compileall -q src tests
python3 -m pytest -q
python3 -m ruff check .
docker compose config >/dev/null
printf '%s\n' "V9.2 SETUP VALIDATED"
