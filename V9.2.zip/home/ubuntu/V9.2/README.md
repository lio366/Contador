# ECO·IA COPILOT V9.2 — Autonomous Governed Execution Platform

## Purpose
V9.2 is the autonomous execution/verification layer for the authorized Healthcare Overlay and Zero-Trust projects. It is separate from V9.1 and does not modify V9.1 during installation.

Mission sequence:
DISCOVERY → ARCHITECTURE → CONFIGURATION → IMPLEMENTATION → SECURITY HARDENING → SYNTHETIC INTEGRATION → TESTING → ZERO-TRUST VERIFICATION → EVIDENCE COLLECTION → AUDIT → FINAL VERDICT → DOCUMENTATION.

## Scope
Allowed projects are explicitly mapped in `mission/scope.json`:
- `/home/ubuntu/ECOIA-NORIDIAN/ECOIA-HEALTHCARE-OVERLAY`
- `/home/ubuntu/ECOIA_ZERO_TRUST_AUTONOMOUS`

Excluded and not mounted into V9.2 containers:
- `/home/ubuntu/ECO-IA`
- `/opt/taes`
- `/opt/taes2`

Healthcare data for the Las Mercedes laboratory is SYNTHETIC. V9.2 never treats synthetic records or synthetic adapters as real integration.

## Core design
- 9 agents, all inheriting from `BaseAgent`.
- TOMY-derived in-process async `MessageBus` for same-process delivery.
- Redis Pub/Sub for live inter-agent events and Redis Streams for durable/replayable events. Redis Pub/Sub itself is at-most-once, so durable mission events are written to a Stream.
- PostgreSQL for persistent mission/task/evidence state.
- FastAPI for REST and automatic OpenAPI/Swagger documentation.
- GPT-4.1 through the OpenAI Responses API for selected strategic reasoning; Ollama for local/economic routine reasoning.
- Docker Compose with separate API, orchestrator, worker, executor, database, Redis, Prometheus and Grafana services.
- Policy Gate, immutable Mission Contract, protected-test integrity, checkpoint/rollback, independent evidence verification and final Evidence Judge.

## Agent roles
1. Master Orchestrator — mission control and priorities.
2. Monetization — Stripe/customer/billing proposals; financial mutations are controlled.
3. DevOps — build/deploy/health/recovery operations.
4. Resources — CPU/RAM/disk/queue capacity.
5. Security — scope, secrets, permissions, Zero Trust checks.
6. Analytics — metrics, anomalies and reports.
7. Builder — evidence-backed implementation using controlled patches.
8. Repair — evidence-backed repair with checkpoint and rollback.
9. Verification — test execution, reproduction, critic review and evidence judgment.

The nine roles do not imply nine separate LLMs or nine containers. They share the economical runtime.

## Autonomy model
Agent proposes → Policy Gate validates → Executor executes → Runtime produces evidence → Critic reviews → Independent verifier reproduces → Evidence Judge decides.

The LLM never receives unrestricted authority to execute arbitrary commands. Command execution is deterministic and path allowlisted.

## Model routing
- Routine work: Ollama/local model.
- Complex planning/diagnosis: GPT-4.1 only when `OPENAI_ENABLED=true` and a valid key is supplied.
- The router is fail-closed toward local reasoning if GPT-4.1 is unavailable.

## Important evidence semantics
`IMPLEMENTED ≠ EXECUTED ≠ VERIFIED ≠ REAL INTEGRATION`.

A successful synthetic validation demonstrates technical laboratory operation. It does not demonstrate real integration with Las Mercedes.

Allowed verdict vocabulary:
`PASS`, `FAIL`, `BLOCKED`, `PARTIAL`, `VERIFIED`, `NOT VERIFIED`.

Skipped external dependencies remain `UNVERIFIED` and are never converted to PASS.

## Security boundaries
Only the two allowed project paths are mounted. Excluded paths are absent from the V9.2 container namespace. Controlled writes require a checkpoint. Tests are protected by a SHA-256 manifest and the Policy Gate rejects test modification actions.

Docker secrets are supported for API keys. Secrets are never written to evidence payloads or logs.

## Run
```bash
cp .env.example .env
./scripts/setup.sh
./scripts/start.sh
```

Swagger UI: `http://127.0.0.1:8082/docs`
Health: `http://127.0.0.1:8082/health`
Metrics: `http://127.0.0.1:8082/metrics`

## Autonomous mission loop
The orchestrator container starts the mission loop and executes a controlled cycle at `MISSION_INTERVAL_SECONDS`. A cycle performs deterministic recon, runs the authorized test procedures, collects evidence, asks the critic/evidence judge for validation and generates reports. Builder/Repair changes are only attempted when a reproducible failure provides sufficient evidence and the policy gate permits the action.

## Limitations
This repository does not claim HIPAA compliance, certification, production readiness, absolute security, or real Las Mercedes integration. Those require external authorization, real credentials, real sandbox access and the subsequent integration sequence defined by the mission.
